package Protocol

var (
	webport = []string{"80", "443", "8000", "8080", "8443", "8888", "9000"} //常见web服务使用的端口，在数据库扫描中跳过
)
