package global

const (
	Version      = "1.2.5"                                                       //当前版本号
	Releasenotes = "快速扫描更智能;增加多种漏洞识别;WEB扫描增加保存截图功能"                              //版本说明
	RepoUrl      = "https://api.github.com/repos/selinuxg/Golin/releases/latest" //仓库最新版本
)
